window.jQuery = window.$ = require("jquery");

require('es6-promise').polyfill();





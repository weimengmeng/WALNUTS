/**
 * Created by mrwim on 17/11/1.
 */
var app = angular.module('myApp', []);
var $myScope, $myHttp;
var userId="111",token="111",loginUserId;
var articlePage=1,answerPage=1,savePage=1,focusArticlePage=1,focusColumnPage=1,focusUserPage=1,focusTagPage=1,beFocusPage=1;
var otheruserInfo;//其他用户信息
app.controller('myCtrl', function ($scope, $http) {
    $myScope = $scope;
    $myHttp = $http;
    if (!sessionStorage.user) {
        $("#login").show();
        $(".personal").hide();
        $scope.title="未登录";
    } else {
        var user = JSON.parse(sessionStorage.user);
        if (user.token != "") {
            $("#login").hide();
            $scope.name = user.uname;
            $scope.myVar = user.headimg;
            loginUserId=user.uid;
            $scope.introduction=user.introduction;
            $scope.uid = user.uid;
            $scope.token = user.token;
            if(GetQueryString("uid")&&GetQueryString("uid")!=user.uid){
                userId=GetQueryString("uid");
                getOtherUserInfo();
                $("#rightDiv").show();
            }else{
                userId=user.uid;
                token=user.token;
                $scope.title=user.uname+"-核桃";
                var userInfo = JSON.parse(localStorage.userInfo);
                $myScope.username=userInfo.uname;
                $myScope.introduction=userInfo.introduction;
                $myScope.company=userInfo.company;
                $myScope.userHead=userInfo.headimg;
                $myScope.position=userInfo.position;
                $myScope.f_industry_name=userInfo.f_industry_name;
                $myScope.industry_name=userInfo.industry_name;
                $myScope.province_name=userInfo.province_name;
                $myScope.city_name=userInfo.city_name;
                $myScope.follow_num=userInfo.follow_num;
                $myScope.product=userInfo.product;
                $myScope.be_follow_num=userInfo.be_follow_num;
                $scope.saveshow=true;
                $scope.modifyInfo=true;
                $scope.userFocus=true;
                $myScope.focusques=false;
                $scope.showFocusQues=function (i) {
                    $myScope.focusques= true;
                    $("#focusitem").click();
                    switch(i){
                        case 1:
                            $myScope.ul_article=true;
                            $myScope.ul_column=false;
                            $myScope.ul_user=false;
                            $myScope.ul_tag=false;
                            $myScope.ul_be_user=false;
                            $myScope.foucsitem="关注的问题";
                            if(focusArticlePage==1){
                                getFocusArticle();
                            }
                            $myScope.svg2=false;
                            $myScope.svg3=false;
                            $myScope.svg4=false;
                            $scope.svg5=false;
                            break;
                        case 2:
                            $myScope.ul_article=false;
                            $myScope.ul_column=true;
                            $myScope.ul_user=false;
                            $myScope.ul_tag=false;
                            $myScope.ul_be_user=false;
                            $scope.foucsitem="关注的专栏";
                            if(focusColumnPage==1){
                                getFocusColumn();
                            }
                            $scope.svg1=false;
                            $scope.svg3=false;
                            $scope.svg4=false;
                            $scope.svg5=false;
                            break;
                        case 3:
                            $myScope.ul_article=false;
                            $myScope.ul_column=false;
                            $myScope.ul_user=true;
                            $myScope.ul_tag=false;
                            $myScope.ul_be_user=false;
                            $scope.foucsitem="关注的用户";
                            if(focusUserPage==1){
                                getFocusUser();
                            }
                            $scope.svg1=false;
                            $scope.svg2=false;
                            $scope.svg4=false;
                            $scope.svg5=false;
                            break;
                        case 4:
                            $myScope.ul_article=false;
                            $myScope.ul_column=false;
                            $myScope.ul_user=false;
                            $myScope.ul_tag=true;
                            $myScope.ul_be_user=false;
                            $scope.foucsitem="关注的话题";
                            if(focusTagPage==1){
                                getFocusLabel();
                            }
                            $scope.svg1=false;
                            $scope.svg2=false;
                            $scope.svg3=false;
                            $scope.svg5=false;
                            break;
                        case 5:
                            $myScope.ul_article=false;
                            $myScope.ul_column=false;
                            $myScope.ul_user=false;
                            $myScope.ul_tag=false;
                            $myScope.ul_be_user=true;
                            $scope.foucsitem="关注我的人";
                            if(beFocusPage==1){
                               getBeFocusUser();
                            }
                            $scope.svg1=false;
                            $scope.svg2=false;
                            $scope.svg3=false;
                            $scope.svg4=false;
                            break;
                    }
                }
                $("#rightDiv").hide();
            }
            getUidArticle();
            getUidComment();
            if($scope.saveshow==true){
                getUidCollect();
            }
        } else {
            $("#login").show();
            $scope.title="未登录";
        }
    }
});
function getOtherUserInfo() {
    $myHttp({
        method:'POST',
        url:url+'user/getUser',
        params:{uid:loginUserId,ouid:userId}
    }).then(function successCallback(response) {
        otheruserInfo=response.data.data;
        $myScope.title=otheruserInfo.uname+"-的主页";
        $myScope.introduction=otheruserInfo.introduction;
        $myScope.company=otheruserInfo.company==null?"公司未填写":otheruserInfo.company;
        $myScope.position=otheruserInfo.position==null?"职位未填写":otheruserInfo.position;
        $myScope.f_industry_name=otheruserInfo.f_industry_name;
        $myScope.industry_name=otheruserInfo.industry_name;
        $myScope.province_name=otheruserInfo.province_name;
        $myScope.city_name=otheruserInfo.city_name;
        $myScope.follow_num=otheruserInfo.follow_num;
        $myScope.be_follow_num=otheruserInfo.be_follow_num;
        $myScope.product=otheruserInfo.product;
        $myScope.username=otheruserInfo.uname;
        $myScope.userHead=otheruserInfo.headimg;
        if(otheruserInfo.follow_stat==1){
            $("#rightDiv").children("button.layui-btn-normal").text("取消关注");
            $("#rightDiv").children("button.layui-btn-normal").css("background-color","#919b9b");
        }else{
            $("#rightDiv").children("button.layui-btn-normal").text("关注TA");
            $("#rightDiv").children("button.layui-btn-normal").css("background-color","#ffb129");
        }
    },function errorCallback(response) {
        alert("error")
    });
}
function getUidArticle() {
    $myHttp({
        method:'POST',
        url:url+'user/getUidArticle',
        params:{uid:userId,page:articlePage++}
    }).then(function successCallback(response) {
        if(articlePage==2){
            if(JSON.stringify(response.data.data).length==2){
                $myScope.noques=true;
                $myScope.moreques=false;
            }else{
                $myScope.noques=false;
                $myScope.moreques=true;
                $myScope.questions=response.data.data.article;
            }
            $myScope.goDetail=function (position) {
                if($myScope.questions[position].type==1){
                    window.open("quesdetail.html?articleId="+$myScope.questions[position].id,"_blank");
                }else{
                    window.open("articleDetail.html?id="+$myScope.questions[position].id,"_blank");
                }
            };
        }else{
            if(JSON.stringify(response.data.data).length==2){
                layer.msg("已加载全部数据了");
            }else{
                $myScope.questions = $myScope.questions.concat(response.data.data.article);
            }
        }
    },function errorCallback(response) {
        layer.msg('呀，出错了', {icon: 5});
    });
}
function getFocusArticle() {
    $myHttp({
        method:'POST',
        url:url+'index/getFollowArticle',
        params:{uid:userId,page:focusArticlePage++}
    }).then(function successCallback(response) {
        if(focusArticlePage==2){
            if(JSON.stringify(response.data.data).length==2){
                $myScope.svgdiv=true;
                $myScope.svg1=true;
                $myScope.morefocus=false;
            }else{
                $myScope.svg1=false;
                $myScope.svgdiv=false;
                $myScope.morefocus=true;
                $myScope.focusArticles=response.data.data.article;
            }
        }else{
            if(JSON.stringify(response.data.data).length==2){
                layer.msg("已加载全部数据了");
            }else{
                $myScope.focusArticles = $myScope.focusArticles.concat(response.data.data.article);
            }
        }
    },function errorCallback(response) {
        layer.msg('呀，出错了', {icon: 5});
    });
}
function getFocusColumn() {
    $myHttp({
        method:'POST',
        url:url+'index/getFollowColumn',
        params:{uid:userId,page:focusColumnPage++,token:token}
    }).then(function successCallback(response) {
        if(focusColumnPage==2){
            if(JSON.stringify(response.data.data).length==2){
                $myScope.svgdiv=true;
                $myScope.svg2=true;
                $myScope.morefocus=false;
            }else{
                $myScope.svg2=false;
                $myScope.svgdiv=false;
                $myScope.morefocus=true;
                $myScope.focusColumns=response.data.data;
                $myScope.toCloumnDetail=function (column_id) {
                    alert(column_id);
                };
            }
        }else{
            if(JSON.stringify(response.data.data).length==2){
                layer.msg("已加载全部数据了");
            }else{
                $myScope.focusColumns = $myScope.focusColumns.concat(response.data.data);
            }
        }
    },function errorCallback(response) {
        layer.msg('呀，出错了', {icon: 5});
    });
}
function getFocusUser() {
    $myHttp({
        method:'POST',
        url:url+'user/getFollowUser',
        params:{uid:userId,page:focusUserPage++,token:token}
    }).then(function successCallback(response) {
        if(focusUserPage==2){
            if(JSON.stringify(response.data.data.user).length==2){
                $myScope.svgdiv=true;
                $myScope.svg3=true;
                $myScope.morefocus=false;
            }else{
                $myScope.svg3=false;
                $myScope.svgdiv=false;
                $myScope.morefocus=true;
                $myScope.focusUsers=response.data.data.user;
            }
        }else{
            if(JSON.stringify(response.data.data).length==2){
                layer.msg("已加载全部数据了");
            }else{
                $myScope.focusUsers = $myScope.focusUsers.concat(response.data.data.user);
            }
        }
    },function errorCallback(response) {
        layer.msg('呀，出错了', {icon: 5});
    });
}
function getBeFocusUser() {
    $myHttp({
        method:'POST',
        url:url+'user/getFollowUser',
        params:{uid:userId,page:beFocusPage++,token:token,select:'2'}
    }).then(function successCallback(response) {
        if(beFocusPage==2){
            if(JSON.stringify(response.data.data.user).length==2){
                $myScope.svgdiv=true;
                $myScope.svg5=true;
                $myScope.morefocus=false;
            }else{
                $myScope.svg5=false;
                $myScope.svgdiv=false;
                $myScope.morefocus=true;
                $myScope.beFocusUsers=response.data.data.user;
            }
        }else{
            if(JSON.stringify(response.data.data).length==2){
                layer.msg("已加载全部数据了");
            }else{
                $myScope.beFocusUsers = $myScope.beFocusUsers.concat(response.data.data.user);
            }
        }
    },function errorCallback(response) {
        layer.msg('呀，出错了', {icon: 5});
    });
}
function getFocusLabel() {
    $myHttp({
        method:'POST',
        url:url+'index/getFollowLabel',
        params:{uid:userId,page:focusTagPage++,token:token}
    }).then(function successCallback(response) {
        if(focusTagPage==2){
            if(JSON.stringify(response.data.data.label).length==2){
                $myScope.svgdiv=true;
                $myScope.svg4=true;
                $myScope.morefocus=false;
            }else{
                $myScope.svg4=false;
                $myScope.svgdiv=false;
                $myScope.morefocus=true;
                $myScope.focusTags=response.data.data.label;
                $myScope.totagHtml=function (label_id,label_name) {
                    localStorage.label_name = label_name;
                    window.open("tagques.html?tagId=" + label_id, "_blank");
                };
            }
        }else{
            if(JSON.stringify(response.data.data).length==2){
                layer.msg("已加载全部数据了");
            }else{
                $myScope.focusTags = $myScope.focusTags.concat(response.data.data.label);
            }
        }
    },function errorCallback(response) {
        layer.msg('呀，出错了', {icon: 5});
    });
}
function getUidComment() {
    $myHttp({
        method:'POST',
        url:url+'user/getUidComment',
        params:{uid:userId,page:answerPage++}
    }).then(function successCallback(response) {
        if(answerPage==2){
            if(JSON.stringify(response.data.data).length==2){
                $myScope.noanswer=true;
                $myScope.moreanswer=false;
            }else{
                $myScope.noanswer=false;
                $myScope.moreanswer=true;
                $myScope.answers=response.data.data.collect;
                $myScope.goCommentDetail=function (position,article_id,answerid) {
                    window.open("quesdetail.html?articleId="+article_id+"&answer_id="+answerid,"_self");
                };
            }
        }else{
            if(JSON.stringify(response.data.data).length==2){
                layer.msg("已加载全部数据了");
            }else{
                $myScope.answers = $myScope.answers.concat(response.data.data.collect);
            }
        }
    },function errorCallback(response) {
        layer.msg('呀，出错了', {icon: 5});
    });
}
function getUidCollect() {
    $myHttp({
        method:'POST',
        url:url+'user/getUidCollect',
        params:{uid:userId,page:savePage++}
    }).then(function successCallback(response) {
        if(savePage==2){
            $myScope.saves=response.data.data.collect;
            $myScope.goSaveDetail=function (position,article_id,answerid) {
                window.open("quesdetail.html?articleId="+article_id+"&answer_id="+answerid,"_blank");
            };
        }else{
            if(JSON.stringify(response.data.data).length==2){
                layer.msg("已加载全部数据了");
            }else{
                $myScope.saves = $myScope.saves.concat(response.data.data.collect);
            }
        }
    },function errorCallback(response) {
        layer.msg('呀，出错了', {icon: 5});
    });
}
function focusPeople() {
    if (!sessionStorage.user) {
        window.open("login.html", "_self");
        return;
    }else{
        var select;
        if($("#rightDiv").children("button.layui-btn-normal").text()=="取消关注"){
            select=0;
        }else{
          select=1;
        }
        $myHttp({
            method:'POST',
            url:url+'user/followUser',
            params:{uid:loginUserId,token:token,be_uid:userId,select:select}
        }).then(function successCallback(response) {
            if(response.data.succeed==0){
                if(select==1){
                    otheruserInfo.be_follow_num+=1;
                    $myScope.be_follow_num=otheruserInfo.be_follow_num;
                    $("#rightDiv").children("button.layui-btn-normal").text("取消关注");
                    $("#rightDiv").children("button.layui-btn-normal").css("background-color","#919b9b");
                }else{
                    otheruserInfo.be_follow_num-=1;
                    $myScope.be_follow_num=otheruserInfo.be_follow_num;
                    $("#rightDiv").children("button.layui-btn-normal").text("关注TA");
                    $("#rightDiv").children("button.layui-btn-normal").css("background-color","#ffb129");
                }
            }else{
                layer.msg(response.data.msg);
            }
        },function errorCallback(response){
            layer.msg('呀，出错了', {icon: 5});
        });
    }
}
function sendMess() {
    if (!sessionStorage.user) {
        window.open("login.html", "_self");
        return;
    }else{
        alert("该功能暂未开放");
    }
}
function GetQueryString(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
    var r = window.location.search.substr(1).match(reg);
    if (r != null)return unescape(r[2]);
    return null;
}
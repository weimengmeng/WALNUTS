/**
 * Created by mrwim on 17/11/1.
 */
var app = angular.module('myApp', []);
var $myScope, $myHttp;
app.controller('myCtrl', function ($scope, $http) {
    $myScope = $scope;
    $myHttp = $http;
    if (!sessionStorage.user) {
        $("#login").show();
        $(".personal").hide();
    } else {
        var user = JSON.parse(sessionStorage.user);
        if (user.token != "") {
            $("#login").hide();
            $scope.name = user.uname;
            $scope.myVar = user.headimg;
        } else {
            $("#login").show();
        }
    }
});
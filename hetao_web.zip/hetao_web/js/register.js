/**
 * Created by mrwim on 17/10/25.
 */

$(function () {
    if (typeof(localStorage.remember) != "undefined") {
        if (localStorage.remember == "true") {
            $("#remember-me").attr("checked", true);//设置为选中状态
            document.getElementById("phone").value = localStorage.phone;
            document.getElementById("password").value = localStorage.password;
            $(".zt").show();
        } else {
            $(".zt").hide();
            $("#remember-me").attr("checked", false);//设置为选中状态
        }
    } else {
        $(".zt").hide();
        $("#remember-me").attr("checked", false);//设置为选中状态
    }
    var $inputwrapper = $('.phone1');
    $inputwrapper.find('input').on('input propertychange', function () {
        var result = $(this).val();
        if (result.length == 11) {
            layer.load(1);
            $.ajax({
                url: url+'user/getUserInfo',
                type: 'post',
                jsonp: 'jsonpcallback',
                jsonpCallback: "flightHandler",
                async: false,
                data: {
                    'phone': $('.phone1').find('input').val(),
                },
                success: function (json) {
                    layer.closeAll('loading');
                    var jsonReturn = JSON.parse(json);
                    $('.imgcode').attr('src', url+'user/getVerify?phone=' + result + '&t=' + Math.random());
                    if (jsonReturn.data.code == 1) {
                    } else {
                        layer.msg("该手机号已注册")
                    }
                }
            })
        }
    });
});
$(".button_login").click(function () {
    if (!validatemobile($('.phone').find('input').val())) {
        return;
    }
    if (!validatepwd($('.password').find('input').val())) {
        return;
    }
    $.ajax({
        url: url+'user/login',
        type: 'post',
        jsonp: 'jsonpcallback',
        jsonpCallback: "flightHandler",
        async: true,
        data: {
            'phone': $('.phone').find('input').val(),
            'pwd': $('.password').find('input').val(),
            'device_token': "",
        },
        success: function (data) {
            var jsonReturn = JSON.parse(data);
            if (jsonReturn.succeed == 0) {
                if ($("#remember-me").is(":checked")) {
                    localStorage.phone = jsonReturn.data.phone;
                    localStorage.password = $('.password').find('input').val();
                } else {
                    localStorage.password = "";
                }
                sessionStorage.user = JSON.stringify(jsonReturn.data);
                if(document.referrer){
                    window.location.href=document.referrer;
                }else{
                    window.close();
                    window.open("index.html","_blank");
                }
            } else {
                layer.msg(jsonReturn.msg)
            }
        }
    })
})
$('.imgcode').hover(function () {
    layer.tips("看不清？点击更换", '.verify', {
        time: 6000,
        tips: [2, "#3c3c3c"]
    })
}, function () {
    layer.closeAll('tips');
}).click(function () {
    var result = $('.phone1').find('input').val();
    $(this).attr('src', url+'user/getVerify?phone=' + result + '&t=' + Math.random());
});
$("#button-verify").click(function () {
    var result = $('.verify').find('input').val();
    if(!validatemobile1($('.phone1').find('input').val())){
        return;
    }
    if (result.length != 4) {
        layer.msg("请输入图形验证码");
        return;
    }
    $.ajax({
        url: url+'user/sendSms',
        type: 'post',
        jsonp: 'jsonpcallback',
        jsonpCallback: "flightHandler",
        async: false,
        data: {
            'phone': $('.phone1').find('input').val(),
            'imgcode': $('.verify').find('input').val(),
        },
        success: function (data) {
            var jsonReturn = JSON.parse(data);
            if (jsonReturn.succeed == 0) {
                layer.msg("验证码已发送，请注意查收");
                time($("#button-verify"));
            }else{
                layer.msg(jsonReturn.msg)
            }
        }
    })
});
var wait = 60;
function time(button) {
    if (wait == 0) {
        button.attr("disabled",false);
        button.attr("value","获取验证码")
        button.css("color","#ffb129")
        wait = 60;
    } else {
        button.attr("disabled", true);
        button.attr("value","重新发送(" + wait + "S)")
        button.css("color","#999999")
        wait--;
        setTimeout(function () {
                time(button)
            },
            1000)
    }
}
$(".register-btn").click(function () {
    if(!validatemobile1($('.phone1').find('input').val())){
        return;
    }
    if($('.verify').find('input').val().length!= 4) {
        layer.msg("请输入图形验证码");
        return;
    }
    if($('.phone-verify').find('input').val().length<6) {
        layer.msg("请输入六位短信验证码");
        return;
    }
    if(!validatepwd1($('.password1').find('input').val())) {
        return;
    }
    $.ajax({
        url: url+'user/register',
        type: 'post',
        jsonp: 'jsonpcallback',
        jsonpCallback: "flightHandler",
        async: false,
        data: {
            'phone': $('.phone1').find('input').val(),
            'pwd': $('.password1').find('input').val(),
            'code':$('.phone-verify').find('input').val(),
            'device_token':"webregister",
            'register_type':3
        },
        success: function (data) {
            var jsonReturn = JSON.parse(data);
            if (jsonReturn.succeed == 0) {
                layer.msg("恭喜你注册成功");
                sessionStorage.user=JSON.stringify(jsonReturn.data);
                $(".bounceInDown2").click();
                open1();
            }else{
                layer.msg(jsonReturn.msg)
            }
        }
    })
})
$("#remember-me").click(function () {
    var n = $("#remember-me").is(":checked");
    localStorage.remember = n;
    if (n) {
        $(".zt").show();
    } else {
        $(".zt").hide();
    }
});
function validatemobile(mobile)
{
    if(mobile.length==0)
    {
        layer.tips("请输入手机号", '.phone', {
            time: 3000,
            tips: [2, "#3c3c3c"]
        })
        return false;
    }
    var reg = /^1[3|4|5|7|8][0-9]{9}$/; //验证规则
    if(!reg.test(mobile))
    {
        layer.tips("请输入有效手机号", '.phone', {
            time: 3000,
            tips: [2, "#3c3c3c"]
        })
        return false;
    }
    return true;
}
function validatepwd(pwd)
{
    if(pwd.length<6)
    {
        layer.tips("请输入密码", '.password', {
            time: 3000,
            tips: [2, "#3c3c3c"]
        })
        return false;
    }
    return true;
}
function validatemobile1(mobile)
{
    if(mobile.length==0)
    {
        layer.tips("请输入手机号", '.phone1', {
            time: 3000,
            tips: [2, "#3c3c3c"]
        })
        return false;
    }
    var reg = /^1[3|4|5|7|8][0-9]{9}$/; //验证规则
    if(!reg.test(mobile))
    {
        layer.tips("请输入有效手机号", '.phone1', {
            time: 3000,
            tips: [2, "#3c3c3c"]
        })
        return false;
    }
    return true;
}
function validatepwd1(pwd)
{
    if(pwd.length<6)
    {
        layer.tips("请输入六位以上密码", '.password1', {
            time: 3000,
            tips: [2, "#3c3c3c"]
        })
        return false;
    }
    return true;
}
function open1() {
    $("#login").show();
    $("#register").hide();
    $(".slide-bar").removeClass("slide-bar1");
    $("#logindiv").addClass("active");
    $("#registerdiv").removeClass("active");
}
function open2() {
    $("#login").hide();
    $("#register").show();
    $(".slide-bar").addClass("slide-bar1");
    $("#logindiv").removeClass("active");
    $("#registerdiv").addClass("active");
}
// $("#qqLoginBtn").click(function () {
//     var oOpts={
//         appId:"101445100",
//         redirectURI:"http://192.168.1.180/hetao_web/login.html"
//     };
//     QC.Login.showPopup(oOpts);
// });
// if(QC.Login.check()){//如果已登录
//     QC.Login.getMe(function(openId, accessToken){
//         $.ajax({
//             url: "https://graph.qq.com/oauth2.0/me",
//             type: 'post',
//             data:{
//                 access_token:accessToken,
//                 unionid:1
//             },
//             dataType:'jsonp',
//             jsonp: 'callback',
//             jsonpCallback: "callback",
//             async: false,
//             success: function (data) {
// //                    alert(data.unionid);
//                 loginThird(data.unionid,1)
//             },
//         })
//     });
// }
// function loginThird(unionid,type) {
//     $.ajax({
//         url: url+'user/authlogin',
//         type: 'post',
//         data:{
//             logintype:type,
//             uuid:unionid,
//             device_token: "web",
//         },
//         dataType:'json',
//         async: false,
//         success: function (data) {
//             if(data.data["code"] != undefined){
//                 layer.msg("为方便您下次登陆，请先绑定手机号");
//                 open2();
//             }else{
//                 alert(JSON.stringify(data));
//             }
//         },
//     })
// }

/**
 * Created by mrwim on 17/10/31.
 */
var app = angular.module('myApp', []);
var $myScope, $myHttp;
var page1 = 1, page2 = 1, page3 = 1, hotPage = 1;
var userId = "111";
var temp=1;
app.controller('myCtrl', function ($scope, $http) {
    $myScope = $scope;
    $myHttp = $http;
    if (!sessionStorage.user) {
        $("#login").show();
        $(".personal").hide();
    } else {
        var user = JSON.parse(sessionStorage.user);
        if (user.token != "") {
            $("#login").hide();
            userId = user.uid;
            $scope.name = user.uname;
            $scope.myVar = user.headimg;
            $scope.uid = user.uid;
            $scope.token = user.token;
            getUserInfo();
        } else {
            $("#login").show();
        }
    }
    loaddata();
});
function loaddata() {
    $myHttp({
        method: 'POST',
        url: url + 'index/getArticle',
        params: {page: page1++, cate_article_id: '1'}
    }).then(function successCallback(response) {
        $myScope.names = response.data.data.article;
        $("#loadmore1").html("加载更多");
    }, function errorCallback(response) {
        layer.msg('呀，出错了', {icon: 5});
    });
    $myHttp({
        method: 'POST',
        url: url + 'index/getLabel',
    }).then(function successCallback(response) {
        localStorage.labels = JSON.stringify(response.data.data);
    }, function errorCallback(response) {
        layer.msg('呀，出错了', {icon: 5});
    });
    $myHttp({
        method: 'POST',
        url: url + 'index/getArticle',
        params: {page: page2++, cate_article_id: '2'}
    }).then(function successCallback(response) {
        $myScope.names2 = response.data.data.article;
        $("#loadmore2").html("加载更多");
    }, function errorCallback(response) {
        layer.msg('呀，出错了', {icon: 5});
    });
    $myHttp({
        method: 'POST',
        url: url + 'index/getArticle',
        params: {page: page3++, cate_article_id: '3'}
    }).then(function successCallback(response) {
        $myScope.names3 = response.data.data.article;
        $("#loadmore3").html("加载更多");
    }, function errorCallback(response) {
        layer.msg('呀，出错了', {icon: 5});
    });
    $myHttp({
        method: 'POST',
        url: url + 'index/getHotComment',
        params: {page: hotPage++, uid: userId}
    }).then(function successCallback(response) {
        $myScope.selects = response.data.data.comment;
        $("#loadselect").html("加载更多");
        $myScope.focusPeople = function (position, uid) {
            focusPeople(position, uid);
        };
        $myScope.goDetail = function (position, article_id, answerid) {
            window.open("quesdetail.html?articleId=" + article_id + "&answer_id=" + answerid, "_blank");
        };
    }, function errorCallback(response) {
        layer.msg('呀，出错了', {icon: 5});
    });
}
function loadmore1() {
    $myHttp({
        method: 'POST',
        url: url + 'index/getArticle',
        params: {page: page1++, cate_article_id: '1'}
    }).then(function successCallback(response) {
        if (response.data.data.article.length <= 0) {
            layer.msg("已加载全部数据啦")
            $("#loadmore1").html("已加载全部数据");
        } else {
            $myScope.names = $myScope.names.concat(response.data.data.article);
        }
    }, function errorCallback(response) {
        layer.msg('呀，出错了', {icon: 5});
    });
}
function loadmore2() {
    $myHttp({
        method: 'POST',
        url: url + 'index/getArticle',
        params: {page: page2++, cate_article_id: '2'}
    }).then(function successCallback(response) {
        if (response.data.data.article.length <= 0) {
            layer.msg("已加载全部数据啦")
            $("#loadmore2").html("已加载全部数据");
        } else {
            $myScope.names2 = $myScope.names2.concat(response.data.data.article);
        }
    }, function errorCallback(response) {
        layer.msg('呀，出错了', {icon: 5});
    });
}
function loadmore3() {
    $myHttp({
        method: 'POST',
        url: url + 'index/getArticle',
        params: {page: page3++, cate_article_id: '3'}
    }).then(function successCallback(response) {
        if (response.data.data.article.length <= 0) {
            layer.msg("已加载全部数据啦")
            $("#loadmore3").html("已加载全部数据");
        } else {
            $myScope.names3 = $myScope.names3.concat(response.data.data.article);
        }
    }, function errorCallback(response) {
        layer.msg('呀，出错了', {icon: 5});
    });
}
function loadSelect() {
    $myHttp({
        method: 'POST',
        url: url + 'index/getHotComment',
        params: {page: hotPage++, uid: userId}
    }).then(function successCallback(response) {
        if (JSON.stringify(response.data.succeed) == 1) {
            layer.msg("已加载全部数据啦")
            $("#loadselect").html("已加载全部数据");
        } else {
            $myScope.selects = $myScope.selects.concat(response.data.data.comment);
        }
    }, function errorCallback(response) {
        layer.msg('呀，出错了', {icon: 5});
    });
}
function getUserInfo() {
    $myHttp({
        method: 'POST',
        url: url + 'user/getUser',
        params: {uid: userId}
    }).then(function successCallback(response) {
        localStorage.userInfo = JSON.stringify(response.data.data);
    }, function errorCallback(response) {
        layer.msg('呀，出错了', {icon: 5});
    });
}
function focusPeople(position, uid) {
    if (userId == "111") {
        window.open("login.html", "_self");
        return;
    } else {
        var select;
        if ($myScope.selects[position].is_focus == 1) {
            select = 0;
        } else {
            select = 1;
        }
        $myHttp({
            method: 'POST',
            url: url + 'user/followUser',
            params: {uid: userId, be_uid: uid, select: select}
        }).then(function successCallback(response) {
            if(response.data.succeed==0){
                if ($myScope.selects[position].is_focus == 0) {
                    $myScope.selects[position].is_focus = 1;
                } else {
                    $myScope.selects[position].is_focus = 0;
                }
            }else{
                layer.msg(response.data.msg);
            }
        }, function errorCallback(response) {
            layer.msg('呀，出错了', {icon: 5});
        });
    }
}
layui.use(['carousel', 'form'], function () {
    var carousel = layui.carousel
        , form = layui.form;

    //常规轮播
    carousel.render({
        elem: '#test1'
        , arrow: 'always'
    });

    //改变下时间间隔、动画类型、高度
    carousel.render({
        elem: '#test2'
        , interval: 1800
        , anim: 'fade'
        , height: '120px'
    });

    //设定各种参数
    var ins3 = carousel.render({
        elem: '#test3'
    });
    //图片轮播
    carousel.render({
        elem: '#test10'
        , width: '1010px'
        , height: '370px'
        , interval: 3000
    });

    //事件
    carousel.on('change(test4)', function (res) {
        console.log(res)
    });

    var $ = layui.$, active = {
        set: function (othis) {
            var THIS = 'layui-bg-normal'
                , key = othis.data('key')
                , options = {};

            othis.css('background-color', '#5FB878').siblings().removeAttr('style');
            options[key] = othis.data('value');
            ins3.reload(options);
        }
    };

    //监听开关
    form.on('switch(autoplay)', function () {
        ins3.reload({
            autoplay: this.checked
        });
    });

    $('.demoSet').on('keyup', function () {
        var value = this.value
            , options = {};
        if (!/^\d+$/.test(value)) return;

        options[this.name] = value;
        ins3.reload(options);
    });

    //其它示例
    $('.demoTest .layui-btn').on('click', function () {
        var othis = $(this), type = othis.data('type');
        active[type] ? active[type].call(this, othis) : '';
    });
});
layui.use('element', function () {
    $('.site-demo-active').on('click', function () {
        var othis = $(this), type = othis.data('type');
        active[type] ? active[type].call(this, othis) : '';
    });
});
var nav = $(".one"); //得到导航对象
var win = $(window); //得到窗口对象
var sc = $(document);//得到document文档对象。
win.scroll(function () {
    if (sc.scrollTop() >= 380) {
        nav.addClass("fix");
    } else {

        nav.removeClass("fix");
    }

});
function goTagHtml(id,value) {
    localStorage.label_name =value;
    window.open("tagques.html?tagId=" + id, "_blank");
};
$('#downAPP').on('mouseenter', function (e) {
    //显示提示
    mTips.c.x = -250;
    mTips.c.y = -100;
    mTips.s(' <img class="qrcode"  src="http://a.app.qq.com/o/image/microQr.png?pkgName=com.njjd.walnuts" alt="Download app qrcode" style="float: left;width: 200px;height: 200px">', 'success');
});
$('#downAPP').on('mouseleave', function (e) {
    mTips.h();
    mTips.c.x = 10;
    mTips.c.y = 10;
});
function changeTemp(item) {
    temp=item;
}
window.onscroll = function () {
    //监听事件内容
    if(getScrollHeight() == getDocumentTop() + getWindowHeight()){
        switch (temp){
            case 1:
                loadmore1();
                break;
            case 2:
                loadmore2();
                break;
            case 3:
                loadmore3();
                break;
            case 4:
                loadSelect();
                break;
        }
    }
}
/**
 * Created by mrwim on 17/11/2.
 */
var app = angular.module('myApp', []);
var $myScope, $myHttp;
var userId = "111";
var tempTarget;
var answerPage = 1, labelId = 1;
var articleId, answer_id, token = "", orderStr = 'time';
app.controller('myCtrl', function ($scope, $http) {
    $myScope = $scope;
    $myHttp = $http;
    if (!sessionStorage.user) {
        $("#login").show();
        $(".personal").hide();
    } else {
        var user = JSON.parse(sessionStorage.user);
        if (user.token != "") {
            $("#login").hide();
            userId = user.uid;
            token = user.token;
            $scope.name = user.uname;
            $scope.myVar = user.headimg;
        } else {
            $("#login").show();
        }
    }
    articleId = GetQueryString("articleId");
    $scope.url="http://www.heardtalk.com/web/mobile/articleShare?article_id="+articleId;
    getArticleDetail(articleId);
    answer_id = GetQueryString("answer_id");
    if (answer_id != null) {
        getAnswerById(answer_id);
    } else {
        getArticleAnswer(articleId);
        $myScope.shows = false;
    }
});
function getAnswerById(answerId) {
    $myHttp({
        method: 'POST',
        url: url + 'index/getCommentDetail',
        params: {uid: userId, comment_id: answerId}
    }).then(function successCallback(response) {
        $myScope.myanswer = response.data.data;
        $myScope.shows = true;
        $myScope.myanswerComment = false;
        $("#loadmoreAnswers").html("查看其他回答");
        $myScope.more = true;
        $myScope.pointMyComment = function (itemId, stat) {
            if (!sessionStorage.user) {
                window.open("login.html", "_self");
                return;
            } else {
                // alert(itemId);
                if (stat == 0) {
                    $myHttp({
                        method: 'POST',
                        url: url + 'index/setNum',
                        params: {uid: userId, point_comment_id_not: itemId}
                    }).then(function successCallback(response) {
                        layer.msg("取消点赞成功");
                        $myScope.myanswer.is_point = 0;
                        $myScope.myanswer.point_num -= 1;
                    }, function errorCallback(response) {
                        layer.msg(response.data.msg);
                    });
                } else {
                    $myHttp({
                        method: 'POST',
                        url: url + 'index/setNum',
                        params: {uid: userId, point_comment_id: itemId}
                    }).then(function successCallback(response) {
                        layer.msg("点赞成功");
                        $myScope.myanswer.is_point = 1;
                        $myScope.myanswer.point_num += 1;
                    }, function errorCallback(response) {
                        layer.msg(response.data.msg);
                    });
                }
            }
        };
        $myScope.addMyAnswerComment = function ($event, answerId) {
            if (!sessionStorage.user) {
                window.open("login.html", "_self");
                return;
            } else {
                if ($($event.target).prev().prev().val() == "") {
                    layer.msg("请输入评论内容");
                    return;
                } else {
                    $myHttp({
                        method: 'POST',
                        url: url + 'index/addComment',
                        params: {
                            comment_id: answerId,
                            uid: userId,
                            article_id: articleId,
                            content: $($event.target).prev().prev().val(),
                            sec_comment_id: answerId,
                            token: token
                        }
                    }).then(function successCallback(response) {
                        layer.msg("评论成功");
                        getMyCommentById(answerId)
                        $myScope.myanswer.answer_num += 1;
                    }, function errorCallback(response) {
                        layer.msg(response.data.msg);
                    });
                }
            }
        };
        $myScope.openMyComment = function ($event, answerId) {
            if (tempTarget != null) {
                $(tempTarget).removeClass('bg-true');
                $(tempTarget).addClass('bg-false');
            }
            if ($myScope.answers)
                for (var i = 0; i < $myScope.answers.length; i++) {
                    $myScope.answers[i].show = false;
                }
            getMyCommentById(answerId);
            if ($myScope.myanswerComment == false) {
                $($event.target).removeClass('bg-false');
                $($event.target).addClass('bg-true');
                $myScope.myanswerComment = true;
            } else {
                $($event.target).removeClass('bg-true');
                $($event.target).addClass('bg-false');
                $myScope.myanswerComment = false;
            }
            tempTarget = $event.target;
        };
        $myScope.collectMyAnswer = function (itemId, stat) {
            if (stat == 0) {
                $myHttp({
                    method: 'POST',
                    url: url + 'index/setNum',
                    params: {uid: userId, collect_comment_id_not: itemId}
                }).then(function successCallback(response) {
                    //从精选页面点击进入
                    $myScope.myanswer.is_collect = 0;
                    $myScope.myanswer.collect_num -= 1;
                }, function errorCallback(response) {
                    layer.msg(response.data.msg);
                });
            } else {
                $myHttp({
                    method: 'POST',
                    url: url + 'index/setNum',
                    params: {uid: userId, collect_comment_id: itemId}
                }).then(function successCallback(response) {
                    $myScope.myanswer.is_collect = 1;
                    $myScope.myanswer.collect_num += 1;
                }, function errorCallback(response) {
                    layer.msg(response.data.msg);
                });
            }
        };
    }, function errorCallback(response) {

    });
}
function getArticleDetail() {
    $myHttp({
        method: 'POST',
        url: url + 'index/articleDetail',
        params: {id: articleId, uid: userId}
    }).then(function successCallback(response) {
        $myScope.title = response.data.data.title;
        $myScope.article_title = response.data.data.title;
        $myScope.article_content = response.data.data.contents;
        $myScope.answer_num = response.data.data.answer_num;
        $myScope.follow_num = response.data.data.follow_num;
        $myScope.imgs = response.data.data.imgs;
        $myScope.labels = response.data.data.label_name;
        $myScope.ids = response.data.data.label_id;
        getTagQuestions();
        $myScope.gotagHtml = function (position) {
            localStorage.label_name = $myScope.labels.split(",")[position];
            window.open("tagques.html?tagId=" + $myScope.ids.split(",")[position], "_blank");
        };
        if (response.data.data.stat == 1) {
            $("#rightDiv").children("button.layui-btn-normal").text("取消关注");
            $("#rightDiv").children("button.layui-btn-normal").css("background-color", "#919b9b");
        } else {
            $("#rightDiv").children("button.layui-btn-normal").text("关注问题");
            $("#rightDiv").children("button.layui-btn-normal").css("background-color", "#ffb129");
        }
    }, function errorCallback(response) {
        layer.msg('呀，出错了', {icon: 5});
    });
}
function getArticleAnswer() {
    $myHttp({
        method: 'POST',
        url: url + 'index/getCommentF',
        params: {article_id: articleId, uid: userId, page: answerPage++, order: orderStr}
    }).then(function successCallback(response) {
        if (answerPage == 2) {
            if (JSON.stringify(response.data.data).length == 2) {
                $myScope.svgdiv = true;
                $myScope.more = false;
            } else {
                $myScope.svgdiv = false;
                $myScope.more = true;
            }
            $myScope.answers = response.data.data;
            for (var i = 0; i < $myScope.answers.length; i++) {
                if ($myScope.answers[i].id == answer_id) {
                    $myScope.answers.splice(i, 1);
                    break
                }
            }
            $myScope.pointComment = function (itemId, position) {
                pointAnswer(itemId, position);
            };
            $myScope.collect = function (itemId, position) {
                collectAnswer(itemId, position);
            };
            $myScope.openComment = function ($event, position, answerId) {
                if ($myScope.myanswerComment == true) {
                    $myScope.myanswerComment = false;
                }
                if (tempTarget != null) {
                    $(tempTarget).removeClass('bg-true');
                    $(tempTarget).addClass('bg-false');
                }
                getCommentById(answerId);
                if ($myScope.answers[position].show == 0) {
                    $($event.target).removeClass('bg-false');
                    $($event.target).addClass('bg-true');
                    for (var i = 0; i < $myScope.answers.length; i++) {
                        if (i != position)
                            $myScope.answers[i].show = false;
                    }
                    $myScope.answers[position].show = true;
                } else {
                    $($event.target).removeClass('bg-true');
                    $($event.target).addClass('bg-false');
                    $myScope.answers[position].show = false;
                }
                tempTarget = $event.target;
                $("html,body").animate({scrollTop: $($event).offset().top}, 'slow');//1000是ms,也可以用slow代替
            };
            $myScope.addComment = function ($event, outerIndex, answerId) {
                addComment($event, outerIndex, answerId);
            };
            $("#loadmoreAnswers").html("加载更多回答");
        } else {
            if (JSON.stringify(response.data.data).length == 2) {
                layer.msg("已加载全部数据啦");
                $("#loadmoreAnswers").html("已加载全部回答");
            } else {
                $myScope.answers = $myScope.answers.concat(response.data.data);
                for (var i = 0; i < $myScope.answers.length; i++) {
                    if ($myScope.answers[i].id == answer_id) {
                        $myScope.answers.splice(i, 1);
                        break
                    }
                }
            }
        }
    }, function errorCallback(response) {
        layer.msg('呀，出错了', {icon: 5});
    });
}
function getMyCommentById(answerId) {
    $myHttp({
        method: 'POST',
        url: url + 'index/getCommentFt',
        params: {comment_id: answerId, uid: userId}
    }).then(function successCallback(response) {
        $myScope.myanswerComments = response.data.data;
        $myScope.reComment = function ($event, id) {
            if ($($event.target).text() == "立即回复") {
                $($event.target).text("取消回复");
            } else {
                $($event.target).text("立即回复");
            }
            $($event.target).parent().next().toggle("slow");
        }
        $myScope.submit_reComment = function ($event, commentId, answerId) {
            if (!sessionStorage.user) {
                window.open("login.html", "_self");
                return;
            }
            if ($($event.target).parent().prev().val() == "") {
                layer.msg("请输入回复内容");
            } else {
                addReply1(commentId, answerId, $($event.target).parent().prev().val());
            }
        }
    }, function errorCallback(response) {
        layer.msg('呀，出错了', {icon: 5});
    });
}
function getCommentById(answerId) {
    $myHttp({
        method: 'POST',
        url: url + 'index/getCommentFt',
        params: {comment_id: answerId, uid: userId}
    }).then(function successCallback(response) {
        $myScope.comments = response.data.data;
        $myScope.reComment = function ($event) {
            if (!sessionStorage.user) {
                window.open("login.html", "_self");
                return;
            }
            if ($($event.target).text() == "立即回复") {
                $($event.target).text("取消回复");
            } else {
                $($event.target).text("立即回复");
            }
            $($event.target).parent().next().toggle();
            $myScope.submit_reComment = function ($event, commentId, answerId, outIndex) {
                if (!sessionStorage.user) {
                    window.open("login.html", "_self");
                    return;
                }
                if ($($event.target).parent().prev().val() == "") {
                    layer.msg("请输入回复内容");
                } else {
                    addReply(commentId, answerId, $($event.target).parent().prev().val(), outIndex);
                }
            }
        }
    }, function errorCallback(response) {
        layer.msg(JSON.stringify(response.data.msg))
    });
}
function addComment($event, outerIndex, answerId) {
    if (!sessionStorage.user) {
        window.open("login.html", "_self");
        return;
    } else {
        if ($($event.target).prev().prev().val() == "") {
            layer.msg("请输入评论内容");
            return;
        } else {
            $myHttp({
                method: 'POST',
                url: url + 'index/addComment',
                params: {
                    comment_id: answerId,
                    uid: userId,
                    article_id: articleId,
                    content: $($event.target).prev().prev().val(),
                    sec_comment_id: answerId,
                    token: token
                }
            }).then(function successCallback(response) {
                if(response.data.succeed==0){
                layer.msg("评论成功");
                getCommentById(answerId)
                $($event.target).prev().prev().val("");
                $myScope.answers[outerIndex].answer_num = $myScope.answers[outerIndex].answer_num + 1;
                }else{
                    layer.msg(response.data.msg);
                }
            }, function errorCallback(response) {
                layer.msg('呀，出错了', {icon: 5});
            });
        }
    }
}
function addReply(commentId, answerId, content, outerIndex) {
    $myHttp({
        method: 'POST',
        url: url + 'index/addComment',
        params: {
            comment_id: commentId,
            uid: userId,
            article_id: articleId,
            content: content,
            sec_comment_id: answerId,
            token: token
        }
    }).then(function successCallback(response) {
        if(response.data.succeed==0){
        layer.msg("回复成功");
        $myScope.answers[outerIndex].answer_num = $myScope.answers[outerIndex].answer_num + 1;
        getCommentById(answerId)
        }else{
            layer.msg(response.data.msg);
        }
    }, function errorCallback(response) {
        layer.msg('呀，出错了', {icon: 5});
    });
}
function addReply1(commentId, answerId, content) {
    $myHttp({
        method: 'POST',
        url: url + 'index/addComment',
        params: {
            comment_id: commentId,
            uid: userId,
            article_id: articleId,
            content: content,
            sec_comment_id: answerId,
            token: token
        }
    }).then(function successCallback(response) {
        if (response.data.succeed == 0) {
            layer.msg("回复成功");
            if ($myScope.myanswer.comment_answer_num >= 0) {
                $myScope.myanswer.comment_answer_num += 1;
            } else {
                $myScope.myanswer.answer_num += 1;
            }
            getMyCommentById(answerId)
        } else {
            layer.msg(response.data.msg);
        }
    }, function errorCallback(response) {
        layer.msg('呀，出错了', {icon: 5});
    });
}
function pointAnswer(answerId, position) {
    if (!sessionStorage.user) {
        window.open("login.html", "_self");
        return;
    } else {
        if ($myScope.answers[position].p_stat == 1) {
            $myHttp({
                method: 'POST',
                url: url + 'index/setNum',
                params: {uid: userId, point_comment_id_not: answerId}
            }).then(function successCallback(response) {
                if (response.data.succeed == 0) {
                    if ($myScope.answers[position].p_stat == 1) {
                        $myScope.answers[position].p_stat = 0;
                        $myScope.answers[position].point_num = $myScope.answers[position].point_num - 1;
                    } else {
                        $myScope.answers[position].p_stat = 1;
                        $myScope.answers[position].point_num = $myScope.answers[position].point_num + 1;
                    }
                } else {
                    layer.msg(response.data.msg);
                }
            }, function errorCallback(response) {
                layer.msg(response.data.msg);
            });
        } else {
            $myHttp({
                method: 'POST',
                url: url + 'index/setNum',
                params: {uid: userId, point_comment_id: answerId}
            }).then(function successCallback(response) {
                if ($myScope.answers[position].p_stat == 1) {
                    $myScope.answers[position].p_stat = 0;
                    $myScope.answers[position].point_num = $myScope.answers[position].point_num - 1;
                } else {
                    $myScope.answers[position].p_stat = 1;
                    $myScope.answers[position].point_num = $myScope.answers[position].point_num + 1;
                }
            }, function errorCallback(response) {
                layer.msg(response.data.msg);
            });
        }
    }
}
function collectAnswer(answerId, position) {
    if (!sessionStorage.user) {
        window.open("login.html", "_self");
        return;
    } else {
        if ($myScope.answers[position].c_stat == 1) {
            $myHttp({
                method: 'POST',
                url: url + 'index/setNum',
                params: {uid: userId, collect_comment_id_not: answerId}
            }).then(function successCallback(response) {
                if (response.data.succeed == 0) {
                    $myScope.answers[position].c_stat = 0;
                    $myScope.answers[position].collect_num = $myScope.answers[position].collect_num - 1;
                } else {
                    layer.msg(response.data.msg);
                }
            }, function errorCallback(response) {
                layer.msg(response.data.msg);
            });
        } else {
            $myHttp({
                method: 'POST',
                url: url + 'index/setNum',
                params: {uid: userId, collect_comment_id: answerId}
            }).then(function successCallback(response) {
                if (response.data.succeed == 0) {
                    $myScope.answers[position].c_stat = 1;
                    $myScope.answers[position].collect_num = $myScope.answers[position].collect_num + 1;
                } else {
                    layer.msg(response.data.msg);
                }
            }, function errorCallback(response) {
                layer.msg('呀，出错了', {icon: 5});
            });
        }
    }
}
function focusQues() {
    var select = 0;
    if (!sessionStorage.user) {
        window.open("login.html", "_self");
        return;
    } else {
        if ($(".layui-btn-normal").html() == "取消关注") {
            select = 0;
        } else {
            select = 1;
        }
        $myHttp({
            method: 'POST',
            url: url + 'index/followArticle',
            params: {uid: userId, token: token, article_id: articleId, select: select}
        }).then(function successCallback(response) {
            if (response.data.succeed == 0) {
                if (select == 1) {
                    $("#rightDiv").children("button.layui-btn-normal").text("取消关注");
                    $("#rightDiv").children("button.layui-btn-normal").css("background-color", "#919b9b");
                } else {
                    $("#rightDiv").children("button.layui-btn-normal").text("关注问题");
                    $("#rightDiv").children("button.layui-btn-normal").css("background-color", "#ffb129");
                }
            } else {
                layer.msg(response.data.msg);
            }
        }, function errorCallback(response) {
            layer.msg('呀，出错了', {icon: 5});
        })
    }
}
function answerQues() {
    if (!sessionStorage.user) {
        window.open("login.html", "_self");
        return;
    } else {
        $("#answerDiv").toggle("slow");
        if ($("#answerDiv").is(":visible")) {
            mScroll("answerDiv");
        }
    }
}
function pubAnswer() {
    if (!sessionStorage.user) {
        window.open("login.html", "_self");
        return;
    } else {
        if ($("#text_answer").val() == "") {
            layer.msg("请输入回答内容");
        } else {
            $myHttp({
                method: 'POST',
                url: url + 'index/addComment',
                params: {uid: userId, token: token, article_id: articleId, content: $("#text_answer").val()}
            }).then(function successCallback(response) {
                if(response.data.succeed==0){
                answerPage = 1;
                getArticleAnswer(articleId);
                $("#text_answer").val("");
                layer.msg("回答成功");
                }else{
                    layer.msg(response.data.msg);
                }
            }, function errorCallback(response) {
                layer.msg('呀，出错了', {icon: 5});
            })
        }
    }
}
$("#sort_time").click(function () {
    orderStr = "time";
    answerPage = 1;
    getArticleAnswer();
    $("#tempsort").html("按时间<i><img src='images/btn_sort.png'' style='margin-top: -3px'></i>");
});
$("#sort_hot").click(function () {
    orderStr = "hot";
    answerPage = 1;
    getArticleAnswer();
    $("#tempsort").html("按质量<i><img src='images/btn_sort.png' style='margin-top: -3px'></i>");
});
function mScroll(id) {
    $("html,body").stop(true);
    $("html,body").animate({scrollTop: $("#" + id).offset().top - 500}, 1000);
    $("#text_answer").focus();
}
function GetQueryString(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
    var r = window.location.search.substr(1).match(reg);
    if (r != null)return unescape(r[2]);
    return null;
}
function getTagQuestions() {
    $myHttp({
        method: 'POST',
        url: url + 'index/getArticle',
        params: {label_id: $myScope.ids.split(",")[0], page: 1, uid: userId}
    }).then(function successCallback(response) {
        // alert(JSON.stringify(response));
        $myScope.items = response.data.data.article;
    }, function errorCallback(response) {
        layer.msg(response.data.msg);
    });
}
window.onscroll = function () {
    //监听事件内容
    if (getScrollHeight() == getDocumentTop() + getWindowHeight()) {
        if ($("#loadmoreAnswers").html() == "加载更多回答") {
            getArticleAnswer();
        }
    }
}
var nav = $(".one"); //得到导航对象
var win = $(window); //得到窗口对象
var sc = $(document);//得到document文档对象。
win.scroll(function () {
    if (sc.scrollTop() >= 10) {
        nav.addClass("fix");
    } else {

        nav.removeClass("fix");
    }

});
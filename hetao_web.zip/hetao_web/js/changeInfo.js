/**
 * Created by mrwim on 17/11/1.
 */
/**
 * Created by mrwim on 17/10/31.
 */
var $el = $('.dialog');
$el.hDialog({title: '修改信息', width: 500, height: 720, positions: top});
//提交并验证表单
$('.submitBtn').click(function () {
    var $nickname = $('.nickname');
    var $message = $('.message');
    var $position = $('.position');
    var $product = $('.product');
    var $company = $('.company');
    if ($nickname.val() == '') {
        $.tooltip('昵称还没填呢...');
        $nickname.focus();
    } else {
        var user=JSON.parse(sessionStorage.user);
        // setTimeout(function () {
        //     $el.hDialog('close', {box: '#HBox'});
        //
        // }, 2000);
        if($("input[name='img']").val()){
            var form = new FormData(document.getElementById("form1"));
            $.ajax({
                url: url + 'user/uploadHeadImg',
                type: "post",
                data: form,
                processData: false,
                contentType: false,
                jsonp: 'jsonpcallback',
                jsonpCallback: "flightHandler",
                success: function (data) {
                    $myHttp({
                        method: 'POST',
                        url: url + 'user/setUserInfo',
                        params: {uid:user.uid, token: user.token,name:$nickname.val(),sex:$('input:radio[name="sex"]:checked').val(),message:$message.val(),position:$position.val(),company:$company.val()
                            ,product:$product.val(),upload_stat:1,province_id:$myScope.city1.id,city_id:$myScope.city2.id,sales_id:$myScope.selectSale.id,industry_id:$myScope.select2.id}
                    }).then(function successCallback(response) {
                        $el.hDialog('close', {box: '#HBox'});
                        getUserInfo2();
                    }, function errorCallback(response) {
                        alert(JSON.stringify(response.data.msg))
                    });
                },
                error: function (e) {
                    layer.msg("修改失败");
                    layer.closeAll('loading');
                }
            });
        }else{
            $myHttp({
                method: 'POST',
                url: url + 'user/setUserInfo',
                params: {uid:user.uid, token: user.token,name:$nickname.val(),sex:$('input:radio[name="sex"]:checked').val(),message:$message.val(),position:$position.val(),company:$company.val()
                    ,product:$product.val(),upload_stat:1,province_id:$myScope.city1.id,city_id:$myScope.city2.id,sales_id:$myScope.selectSale.id,industry_id:$myScope.select2.id}
            }).then(function successCallback(response) {
                $el.hDialog('close', {box: '#HBox'});
                getUserInfo2();
            }, function errorCallback(response) {
                layer.msg('呀，出错了', {icon: 5});
            });
        }
    }

});
function getUserInfo2() {
    $myHttp({
        method: 'POST',
        url: url + 'user/getUser',
        params: {uid: user.uid}
    }).then(function successCallback(response) {
        alert(JSON.stringify(response));
        localStorage.userInfo = JSON.stringify(response.data.data);
        sessionStorage.user=JSON.stringify(response.data.data);
        window.location.reload();
    }, function errorCallback(response) {
        layer.msg('呀，出错了', {icon: 5});
    });
}
function imgPreview(fileDom) {
    if (window.FileReader) {
        var reader = new FileReader();
    } else {
        alert("您的设备不支持图片预览功能，如需该功能请升级您的设备！");
    }

    //获取文件
    var file = fileDom.files[0];
    var imageType = /^image\//;
    //是否是图片
    if (!imageType.test(file.type)) {
        alert("请选择图片！");
        return;
    }
    //读取完成
    reader.onload = function (e) {
        //获取图片dom
        var img = document.getElementById("preview");
        //图片路径设置为读取的图片
        img.src = e.target.result;
    };
    reader.readAsDataURL(file);
}
function setShowLength(obj, maxlength, id) {
    var rem = maxlength - obj.value.length;
    var wid = id;
    if (rem < 0) {
        rem = 0;
    }
    document.getElementById(wid).innerHTML = "还可以输入" + rem + "字数";
}
function initInfo() {
    var user = JSON.parse(localStorage.userInfo);
    $("#preview").attr("src", user.headimg);
    $("#nickname").val(user.uname);
    $(".message").val(user.introduction);
    $(".company").val(user.company);
    $(".position").val(user.position);
    $(".product").val(user.product);
    $myScope.sex={
        male:user.sex
    }
    getIndustryList();
    getSaleModel();
    getCitys();
}
function getIndustryList() {
    $myHttp({
        method:'POST',
        url:url+'user/getIndustry',
    }).then(function successCallback(response) {
        $myScope.industryList=response.data.data;
        $myScope.selectIndustryChange = function(select1){
            $myScope.select2=$myScope.select1.list[0];
            // industry1=select1.selectedItem;
        };
        var user = JSON.parse(localStorage.userInfo);
        for(var i=0;i< $myScope.industryList.length;i++){
            if($myScope.industryList[i].industry_name==user.f_industry_name){
                $myScope.select1=$myScope.industryList[i];
                for(var j=0;j<$myScope.industryList[i].list.length;j++){
                    if($myScope.industryList[i].list[j].industry_name==user.industry_name){
                        $myScope.select2=$myScope.industryList[i].list[j];
                        break;
                    }
                }
                break;
            }
        }
    },function errorCallback(response) {
        layer.msg('呀，出错了', {icon: 5});
    });
}
function getSaleModel() {
    $myHttp({
        method:'POST',
        url:url+'user/getSalesModel'
    }).then(function successCallback(response) {
        //父级绑定事件改变seelct2的值
        $myScope.salesModel=response.data.data;
        var user = JSON.parse(localStorage.userInfo);
        for(var i=0;i< $myScope.salesModel.length;i++){
            if($myScope.salesModel[i].sales_name==user.sales_name){
                $myScope.selectSale=$myScope.salesModel[i];
                break;
            }
        }
    },function errorCallback(response) {
        layer.msg('呀，出错了', {icon: 5});
    });
}
function getCitys() {
    $myHttp({
        method:'POST',
        url:url+'user/getCity'
    }).then(function successCallback(response) {
        $myScope.cityList=response.data.data;
        $myScope.selectCityChange = function(){
            $myScope.city2=$myScope.city1.citylist[0];
        };
        var user = JSON.parse(localStorage.userInfo);
        for(var i=0;i< $myScope.cityList.length;i++){
            if($myScope.cityList[i].name==user.province_name){
                $myScope.city1=$myScope.cityList[i];
                for(var j=0;j<$myScope.cityList[i].citylist.length;j++){
                    if($myScope.cityList[i].citylist[j].name==user.city_name){
                        $myScope.city2=$myScope.cityList[i].citylist[j];
                        break;
                    }
                }
                break;
            }
        }
    },function errorCallback(response) {
        layer.msg('呀，出错了', {icon: 5});
    });
}
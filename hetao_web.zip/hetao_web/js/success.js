/**
 * Created by mrwim on 17/11/14.
 */
var app = angular.module('myApp', []);
var $myScope, $myHttp;
var user;
app.controller('myCtrl', function ($scope, $http) {
    $myScope = $scope;
    $myHttp = $http;
    getIndustryList();
    getSaleModel();
    getCitys();
});
var w, h, className;
function getSrceenWH() {
    w = $(window).width();
    h = $(window).height();
    $('#dialogBg').width(w).height(h);
}

window.onresize = function () {
    getSrceenWH();
}
$(window).resize();

$(function () {
    getSrceenWH();
    $('.bounceInDown2').click(function () {
        user=JSON.parse(sessionStorage.user);
        $myScope.uid=user.uid;
        $myScope.token=user.token;
            className = $(this).attr('class');
            $('#dialogBg').fadeIn(100);
            $('#dialog').removeAttr('class').addClass('animated ' + className + '').fadeIn();
    });
    //关闭弹窗
    $('.claseDialogBtn').click(function () {
        $('#dialogBg').fadeOut(100, function () {
            $('#dialog').addClass('bounceOutUp').fadeOut();
        });
    });
});
function checkForm() {
    var $nickname = $('.username');
    if($("input[name='img']").val()){
        var form = new FormData(document.getElementById("form1"));
        $.ajax({
            url: url + 'user/uploadHeadImg',
            type: "post",
            data: form,
            processData: false,
            contentType: false,
            jsonp: 'jsonpcallback',
            jsonpCallback: "flightHandler",
            success: function (data) {
                $myHttp({
                    method: 'POST',
                    url: url + 'user/setUserInfo',
                    params: {uid:user.uid, token: user.token,name:$nickname.val(),sex:1,
                        position:"",company:"",message:"", product:"",upload_stat:1,province_id:$myScope.city1.id,sales_id: $myScope.selectSale.id,city_id:$myScope.city2.id,industry_id:$myScope.select2.id}
                }).then(function successCallback(response) {
                    layer.msg("完善成功");
                    $('.claseDialogBtn').click();
                }, function errorCallback(response) {
                    alert(JSON.stringify(response.data.msg))
                });
            },
            error: function (e) {
                layer.closeAll('loading');
            }
        });
    }else{
        $myHttp({
            method: 'POST',
            url: url + 'user/setUserInfo',
            params: {uid:user.uid, token: user.token,name:$nickname.val(),sex:1,
                position:"",company:"",message:"", product:"",upload_stat:0,province_id:$myScope.city1.id,sales_id: $myScope.selectSale.id,city_id:$myScope.city2.id,industry_id:$myScope.select2.id}
        }).then(function successCallback(response) {
            layer.msg("完善成功");
            $('.claseDialogBtn').click();
        }, function errorCallback(response) {
            alert(JSON.stringify(response.data.msg))
        });
    }
}
function imgPreview(fileDom) {
    if (window.FileReader) {
        var reader = new FileReader();
    } else {
        alert("您的设备不支持图片预览功能，如需该功能请升级您的设备！");
    }

    //获取文件
    var file = fileDom.files[0];
    var imageType = /^image\//;
    //是否是图片
    if (!imageType.test(file.type)) {
        alert("请选择图片！");
        return;
    }
    //读取完成
    reader.onload = function (e) {
        //获取图片dom
        var img = document.getElementById("preview");
        //图片路径设置为读取的图片
        img.src = e.target.result;
    };
    reader.readAsDataURL(file);
}
function getIndustryList() {
    $myHttp({
        method:'POST',
        url:url+'user/getIndustry',
    }).then(function successCallback(response) {
        $myScope.industryList=response.data.data;
        $myScope.selectIndustryChange = function(select1){
            $myScope.select2=$myScope.select1.list[0];
        };
        $myScope.select1=$myScope.industryList[0];
        $myScope.select2=$myScope.select1.list[0];
    },function errorCallback(response) {
        alert("error")
    });
}
function getSaleModel() {
    $myHttp({
        method:'POST',
        url:url+'user/getSalesModel'
    }).then(function successCallback(response) {
        //父级绑定事件改变seelct2的值
        $myScope.salesModel=response.data.data;
        $myScope.selectSale=$myScope.salesModel[0];
    },function errorCallback(response) {
        alert("error")
    });
}
function getCitys() {
    $myHttp({
        method:'POST',
        url:url+'user/getCity'
    }).then(function successCallback(response) {
        $myScope.cityList=response.data.data;
        $myScope.selectCityChange = function(){
            $myScope.city2=$myScope.city1.citylist[0];
        };
        $myScope.city1=$myScope.cityList[0];
        $myScope.city2=$myScope.city1.citylist[0];
    },function errorCallback(response) {
        alert("error")
    });
}
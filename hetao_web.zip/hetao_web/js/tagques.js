/**
 * Created by mrwim on 17/11/10.
 */
var app = angular.module('myApp', []);
var $myScope, $myHttp;
var tagId,tagPage=1,userId="111",token="";
app.controller('myCtrl', function ($scope, $http) {
    $myScope = $scope;
    $myHttp = $http;
    if (!sessionStorage.user) {
        $("#login").show();
        $(".personal").hide();
    } else {
        var user = JSON.parse(sessionStorage.user);
        if (user.token != "") {
            $("#login").hide();
            $scope.name = user.uname;
            $scope.myVar = user.headimg;
            userId=user.uid;
            token=user.token;
        } else {
            $("#login").show();
        }
    }
    tagId=GetQueryString("tagId");
    $scope.title=localStorage.label_name;
    getTagQuestions();
});
function getTagQuestions() {
    $myHttp({
        method:'POST',
        url:url+'index/getArticle',
        params:{label_id:tagId,page:tagPage++,uid:userId}
    }).then(function successCallback(response) {
        if(tagPage==2){
            $myScope.questions=response.data.data.article;
            if(response.data.data.label_stat==1){
                $(".layui-btn-normal").text("取消关注");
                $(".layui-btn-normal").css("background-color", "#919b9b");
            }else{
                $(".layui-btn-normal").text("关注话题");
                $(".layui-btn-normal").css("background-color", "#33adff");
            }
        }else{
            if(JSON.stringify(response.data.data.article).length==2){
                layer.msg("已加载全部数据啦");
                $("#loadmore1").html("已加载全部数据");
            }else{
                $myScope.questions= $myScope.questions.concat(response.data.data.article);
            }
        }
    },function errorCallback(response) {
        layer.msg('呀，出错了', {icon: 5});
    });
}
function focusTag() {
    if(!sessionStorage.user){
        window.open("login.html","_self");
        return;
    }else{
        var select;
        if($(".layui-btn-normal").text()=="取消关注"){
            select=0;
        }else{
            select=1;
        }
        $myHttp({
            method:'POST',
            url:url+'index/followLabel',
            params:{uid:userId,token:token,label_id:tagId,select:select}
        }).then(function successCallback(response) {
            if(select==1){
                $(".layui-btn-normal").text("取消关注");
                $(".layui-btn-normal").css("background-color", "#919b9b");
            }else{

                $(".layui-btn-normal").text("关注话题");
                $(".layui-btn-normal").css("background-color", "#33adff");
            }
        },function errorCallback(response) {
            layer.msg('呀，出错了', {icon: 5});
        });
    }
}
function GetQueryString(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
    var r = window.location.search.substr(1).match(reg);
    if (r != null)return unescape(r[2]);
    return null;
}
window.onscroll = function () {
    if(getScrollHeight() == getDocumentTop() + getWindowHeight()) {
        getTagQuestions();
    }
}
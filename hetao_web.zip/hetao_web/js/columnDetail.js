/**
 * Created by mrwim on 17/11/29.
 */
var app = angular.module('myApp', []);
var $myScope, $myHttp;
var userId = "111", token = "123";
var column_id = 0, articlesPage = 1;
app.controller('myCtrl', function ($scope, $http) {
    $myScope = $scope;
    $myHttp = $http;
    if (!sessionStorage.user) {
        $("#login").show();
        $(".personal").hide();
    } else {
        var user = JSON.parse(sessionStorage.user);
        if (user.token != "") {
            $("#login").hide();
            $scope.name = user.uname;
            $scope.myVar = user.headimg;
            userId = user.uid;
            token = user.token;
        } else {
            $("#login").show();
        }
    }
    $myScope.url = url.replace("api/", "");
    column_id = GetQueryString("columnId");
    getColumnDetail();
    getArticlesByColumnId();
});
function getColumnDetail() {
    $myHttp({
        method: 'POST',
        url: url + 'index/getColumnDetail',
        params: {
            uid: userId,
            token: token,
            column_id: column_id
        }
    }).then(function successCallback(response) {
        $myScope.uname = response.data.data.uname;
        $myScope.article = {
            column_name: response.data.data.column_name,
            head: response.data.data.headimg,
            desci: response.data.data.desc,
            uid: response.data.data.uid,
            bg: response.data.data.bg_img,
            img:response.data.data.img,
            is_follow:response.data.data.is_follow
        }
        $myScope.focusColumn=function () {
            if(!sessionStorage.user){
                window.open("login.html", "_self");
                return;
            }else{
                $myHttp({
                    method: 'POST',
                    url: url + 'index/followColumn',
                    params: {
                        uid: userId,
                        token: token,
                        column_id: column_id,
                        select:$myScope.article.is_follow==0?1:0
                    }
                }).then(function successCallback(response) {
                    if (response.data.succeed == 0) {
                        $myScope.article.is_follow=$myScope.article.is_follow==0?1:0;
                    }else{
                        layer.msg(response.data.msg);
                    }
                },function errorCallback(response) {
                    layer.msg('呀，出错了', {icon: 5});
                });
            }
        }
    }, function errorCallback(response) {
        layer.msg('呀，出错了', {icon: 5});
    })
}
function getArticlesByColumnId() {
    $myHttp({
        method: 'POST',
        url: url + 'index/getColumnArticles',
        params: {
            uid: userId,
            token: token,
            column_id: column_id,
            page: articlesPage++
        }
    }).then(function successCallback(response) {
        if (response.data.succeed == 0) {
            var columns = response.data.data;
            for (var i = 0; i < columns.length; i++) {
                columns[i].imgs = columns[i].imgs.replace('[', '').replace(']', '').replace(/\"/g, "");
                columns[i].add_time = formatMsgTime(columns[i].add_time);
            }
            if (articlesPage == 2) {
                $myScope.articles = columns;
            } else {
                if(JSON.stringify(response.data.data).length==2){
                    layer.msg("已加载全部");
                }else{
                    $myScope.articles=$myScope.articles.contact(columns);
                }
            }
        } else {
            layer.msg(response.data.msg);
        }
    }, function errorCallback(response) {
        layer.msg('呀，出错了', {icon: 5});
    })
}
function GetQueryString(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
    var r = window.location.search.substr(1).match(reg);
    if (r != null)return unescape(r[2]);
    return null;
}
window.onscroll = function () {
    //监听事件内容
    if (getScrollHeight() == getDocumentTop() + getWindowHeight()) {
        getArticlesByColumnId();
    }
}

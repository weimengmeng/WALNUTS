/**
 * Created by mrwim on 17/11/14.
 */
var w, h, className;
function getSrceenWH() {
    w = $(window).width();
    h = $(window).height();
    $('#dialogBg').width(w).height(h);
}

window.onresize = function () {
    getSrceenWH();
}
$(window).resize();

$(function () {
    getSrceenWH();

    $('.bounceInDown').click(function () {
        if (!sessionStorage.user) {
            window.open("login.html", "_self");
            return;
        } else {
            className = $(this).attr('class');
            $('#dialogBg').fadeIn(100);
            $('#dialog').removeAttr('class').addClass('animated ' + className + '').fadeIn();
        }
    });

    //关闭弹窗
    $('.claseDialogBtn').click(function () {
        $('#dialogBg').fadeOut(100, function () {
            $('#dialog').addClass('bounceOutUp').fadeOut();
        });
    });
});
$("#label_value").click(function () {
    layer.open({
        type: 2,
        title:'为您的问题选择合适的话题',
        area: ['700px', '450px'],
        fixed: false, //不固定
        maxmin: true,
        content: 'selectTag.html'
    });
})
layui.use('upload', function () {
    var $ = layui.jquery
        , upload = layui.upload;
    upload.render({
        elem: '#upfile'
        , url: '/upload/'
        , auto: false
        , multiple: true
        , choose: function (obj) {
            obj.preview(function (index, file, result) {
                if ($('#demo2').children().length >= 9) {
                    layer.msg("最多9张");
                    return;
                }
                $('#demo2').append('<img src="' + result + '" alt="' + file.name + '" class="layui-upload-img" style="width:50px;height:50px;margin: 5px 5px">')
            });
        }
    });
});
function checkForm() {
    if ($("#title").val().length < 5 || $("#title").val() == "") {
        layer.msg("标题不得少于5个字");
        return;
    }
    if ($("#content").val() == "") {
        layer.msg("请输入问题描述");
        return;
    }
    layer.load();
    var form = new FormData(document.getElementById("form1"));
    $.ajax({
        url: url + 'index/addArticle',
        type: "post",
        data: form,
        processData: false,
        contentType: false,
        jsonp: 'jsonpcallback',
        jsonpCallback: "flightHandler",
        success: function (data) {
            var jsonReturn = JSON.parse(data);
            if (jsonReturn.succeed == 0) {
                $('#dialogBg').fadeOut(100, function () {
                    $('#dialog').addClass('bounceOutUp').fadeOut();
                });
                layer.msg("提问成功");
                window.location.reload();
            } else {
                layer.msg(data.msg);
            }
            layer.closeAll('loading');
        },
        error: function (e) {
            layer.msg("提问失败");
            layer.closeAll('loading');
        }
    });
}
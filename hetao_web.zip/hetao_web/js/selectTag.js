/**
 * Created by mrwim on 17/11/14.
 */
var app = angular.module('myApp', []);
app.controller('myCtrl', function ($scope, $http) {
    $scope.labels=JSON.parse(localStorage.labels);
});
//自定义指令repeatFinish
app.directive('repeatFinish',function(){
    return {
        link: function(scope,element,attr){
            if(scope.$last == true){
                $("input").each(function () {
                    $(this).click(function () {
                        if($(this).parent().parent().attr("class")=="label1"){
                            $(".label2 input").attr("disabled", "disabled");
                        }else{
                            $(".label1 input").attr("disabled", "disabled");
                        }
                        $("#value").html("");
                        $("#value2").html("");
                        $("input").each(function () {
                            if($(this).prop("checked")){
                                $("#value").append($(this).val()+",");
                                $("#value2").append($(this).attr("id")+",");
                            }else{
                            }
                        })
                        $("#value").html( $("#value").text().substring(0,$("#value").text().length-1));
                        $("#value2").html( $("#value2").text().substring(0,$("#value2").text().length-1));
                        if($("#value").text()==""){
                            $("input").removeAttr("disabled");
                        }
                    })
                })
            }
        }
    }
})
/**
 * Created by mrwim on 17/11/1.
 */
var app = angular.module('myApp', []);
var $myScope, $myHttp;
var page=1;
app.controller('myCtrl', function ($scope, $http) {
    $myScope = $scope;
    $myHttp = $http;
    if (!sessionStorage.user) {
        $("#login").show();
        $(".personal").hide();
    } else {
        var user = JSON.parse(sessionStorage.user);
        if (user.token != "") {
            $("#login").hide();
            $scope.name = user.uname;
            $scope.myVar = user.headimg;
        } else {
            $("#login").show();
        }
    }
    $myScope.url=url.replace("api/","");
    getColumn();
    getSelectArticle();
});
function getColumn() {
    $myHttp({
        method:'POST',
        url:url+'index/getColumn',
        params:{
            uid:"123"
        }
    }).then(function successCallback(response) {
        $myScope.columns=response.data.data.column;
        $myScope.goColumn=function (id) {
            window.open("columnDetail.html?columnId="+id,"_blank")
        }
    },function errorCallback(response) {
        layer.msg('呀，出错了', {icon: 5});
    });
}
function getSelectArticle() {
    $myHttp({
        method:'POST',
        url:url+'index/getColumnArticle',
        params:{
            uid:"123"
        }
    }).then(function successCallback(response) {
        var columns=response.data.data.column;
        for(var i=0;i<columns.length;i++){
            columns[i].imgs=columns[i].imgs.replace('[','').replace(']','').replace(/\"/g, "");
        }
        $myScope.articles=columns;
    },function errorCallback(response) {
        layer.msg('呀，出错了', {icon: 5});
    });
}
function getAllArticle() {
    $myHttp({
        method:'POST',
        url:url+'index/getColumnArticleAll',
        params:{
            uid:"123",
            page:page++
        }
    }).then(function successCallback(response) {
        var columns=response.data.data.column;
        for(var i=0;i<columns.length;i++){
            columns[i].imgs=columns[i].imgs.replace('[','').replace(']','').replace(/\"/g, "");
        }
        if(page==2){
            $myScope.allArticles=columns;
        }else{
            if(response.data.data.column.length==0){
                layer.msg("已加载全部文章");
            }else{
                $myScope.allArticles=$myScope.allArticles.contact(columns);
            }
        }
    },function errorCallback(response) {
        layer.msg('呀，出错了', {icon: 5});
    });
}
window.onscroll = function () {
    //监听事件内容
    if (getScrollHeight() == getDocumentTop() + getWindowHeight()) {
        getAllArticle();
    }
}
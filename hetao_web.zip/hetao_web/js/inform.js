/**
 * Created by mrwim on 17/11/21.
 */
var app = angular.module('myApp', []);
var page=1;
var $myScope, $myHttp;
var userId="111";
app.controller('myCtrl', function ($scope, $http) {
    $myScope = $scope;
    $myHttp = $http;
    if (!sessionStorage.user) {
        $("#login").show();
        $(".personal").hide();
    } else {
        var user = JSON.parse(sessionStorage.user);
        if (user.token != "") {
            $("#login").hide();
            $scope.name = user.uname;
            $scope.myVar = user.headimg;
            userId=user.uid;
            getInform();
        } else {
            $("#login").show();
        }
    }
});
function getInform() {
    $myHttp({
        method:'POST',
        url:url+'ads/getnotice',
        params:{uid:userId,page:page++}
    }).then(function successCallback(response) {
        if(page==2){
            $myScope.notices=response.data.data.notice;
        }else{
            if(response.data.succeed== 1){
               layer.msg("已加载全部数据");
            }else{
                $myScope.notices= $myScope.notices.concat(response.data.data.notice);
            }
        }
        $myScope.goQuestion=function (articleId,answerId) {
            window.open("quesdetail.html?articleId=" + articleId + "&answer_id=" + answerId, "_blank");
        }
    },function errorCallback(response) {

    });
}
window.onscroll = function () {
    if(getScrollHeight() == getDocumentTop() + getWindowHeight()) {
        //监听事件内容
        getInform();
    }
}
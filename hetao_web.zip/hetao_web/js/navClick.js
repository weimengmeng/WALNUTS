/**
 * Created by mrwim on 17/10/26.
 */
$(".main").click(function () {
    window.open("http://www.heardtalk.com", "_blank");
});
$(".index").click(function () {
    window.location.href='index.html';
});
$(".column").click(function () {
    window.location.href='column.html';
});
$(".about").click(function () {
    window.location.href='about.html';
});
$("#people").click(function () {
    window.location.href='userIndex.html';
});
$("#exit").click(function () {
    sessionStorage.clear();
    window.location.reload();
});
$("#chat").click(function () {
    layer.open({
        type: 1
        ,offset: 't' //具体配置参考：offset参数项
        ,content: '<div style="padding: 20px 80px;">该功能尚未开通,尽请期待!<br/>更多体验,尽在核桃社区APP!</div>'
        ,btn: '知道了'
        ,btnAlign: 'c' //按钮居中
        ,shade: 0 //不显示遮罩
        ,yes: function(){
            layer.closeAll();
        }
    });
    // if(!sessionStorage.user){
    //     window.open("login.html", "_self");
    //     return;
    // }else{
    //     window.open("web-im-master/chat.html" , "_blank");
    // }
});
$("#inform").click(function () {
    if(!sessionStorage.user){
        window.open("login.html", "_self");
        return;
    }else{
        window.open("inform.html", "_self");
    }
});
//文档高度
function getDocumentTop() {
    var scrollTop = 0, bodyScrollTop = 0, documentScrollTop = 0;
    if (document.body) {
        bodyScrollTop = document.body.scrollTop;
    }
    if (document.documentElement) {
        documentScrollTop = document.documentElement.scrollTop;
    }
    scrollTop = (bodyScrollTop - documentScrollTop > 0) ? bodyScrollTop : documentScrollTop;
    return scrollTop;
}

//可视窗口高度
function getWindowHeight() {
    var windowHeight = 0;
    if (document.compatMode == "CSS1Compat") {
        windowHeight = document.documentElement.clientHeight;
    } else {
        windowHeight = document.body.clientHeight;
    }
    return windowHeight;
}

//滚动条滚动高度
function getScrollHeight() {
    var scrollHeight = 0, bodyScrollHeight = 0, documentScrollHeight = 0;
    if (document.body) {
        bodyScrollHeight = document.body.scrollHeight;
    }
    if (document.documentElement) {
        documentScrollHeight = document.documentElement.scrollHeight;
    }
    scrollHeight = (bodyScrollHeight - documentScrollHeight > 0) ? bodyScrollHeight : documentScrollHeight;
    return scrollHeight;
}

function getNotice() {
    if(sessionStorage.user) {
        var u=JSON.parse(sessionStorage.user);
        $myHttp({
            method:'POST',
            url:url+'ads/getnotice',
            params:{uid:u.uid,page:1}
        }).then(function successCallback(response) {
            $myScope.notices=response.data.data.notice;
            $myScope.goQuestion=function (articleId,answerId) {
                window.open("quesdetail.html?articleId=" + articleId + "&answer_id=" + answerId, "_blank");
            }
        },function errorCallback(response) {

        });
    }
}
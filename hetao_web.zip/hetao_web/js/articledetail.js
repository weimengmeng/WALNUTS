/**
 * Created by mrwim on 17/11/29.
 */
/**
 * Created by mrwim on 17/11/1.
 */
var app = angular.module('myApp', ['ngSanitize']);
var $myScope, $myHttp;
var articleId=0;
var $mysce;
var userId="111",token;
var tempTarget;
var answerPage=1;
app.controller('myCtrl', function ($scope, $http,$sce) {
    $myScope = $scope;
    $myHttp = $http;
    $mysce=$sce;
    if (!sessionStorage.user) {
        $("#login").show();
        $(".personal").hide();
    } else {
        var user = JSON.parse(sessionStorage.user);
        if (user.token != "") {
            $("#login").hide();
            $scope.name = user.uname;
            $scope.myVar = user.headimg;
            userId=user.uid;
            token=user.token;
        } else {
            $("#login").show();
        }
    }
    articleId=GetQueryString("id");
    $myScope.url="http://www.heardtalk.com/web/mobile/articleShare?article_id="+articleId;
    getDetail();
    getOtherArticles();
    getArticleComment();
});
function getDetail() {
    $myHttp({
        method:'POST',
        url:url+'index/getColumnArticleDetail',
        params:{
            article_id:articleId,
            uid:userId
        }
    }).then(function successCallback(response) {
        $myScope.title=response.data.data.column_detail.title;
        $myScope.desci=response.data.data.column_detail.desci;
        $myScope.article={
            uid:response.data.data.column_detail.uid,
            uname:response.data.data.column_detail.uname,
            headimg:response.data.data.column_detail.headimg,
            time:response.data.data.column_detail.add_time,
            column_name:response.data.data.column_detail.column_name,
            is_collect:response.data.data.column_detail.is_collect,
            id:response.data.data.column_detail.id,
        }
        $myScope.html = $mysce.trustAsHtml(response.data.data.column_detail.contents);
        $myScope.saveArticle=function(stat)  {
            if (!sessionStorage.user) {
                window.open("login.html", "_self");
                return;
            } else {
                $myHttp({
                    method: 'POST',
                    url: url + 'index/setCollectColumn',
                    params: {uid: userId, token: token, article_id: articleId, select: stat}
                }).then(function successCallback(response) {
                    if(response.data.succeed==0){
                        if (stat == 1) {
                            $myScope.article.is_collect=1;
                        } else {
                            $myScope.article.is_collect=0;
                        }
                    }
                }, function errorCallback(response) {
                    layer.msg(response.data.msg);
                })
            }
        }
    },function errorCallback(response) {

    })
}
function getOtherArticles() {
    $myHttp({
        method:'POST',
        url:url+'index/getRecommendArticle',
        params:{
            article_id:articleId,
        }
    }).then(function successCallback(response) {
        $myScope.items=response.data.data.column;
    },function errorCallback(response) {

    })
}
function getArticleComment() {
    $myHttp({
        method: 'POST',
        url: url + 'index/getCommentF',
        params: {article_id: articleId, uid: userId, page: answerPage++}
    }).then(function successCallback(response) {
        if (answerPage == 2) {
            if (JSON.stringify(response.data.data).length == 2) {
                $myScope.noanswer=true;
                $myScope.more = false;
            } else {
                $myScope.noanswer=false;
                $myScope.more = true;
            }
            $myScope.answers = response.data.data;
            $myScope.openComment = function ($event, position, answerId) {
                if (tempTarget != null) {
                    $(tempTarget).removeClass('bg-true');
                    $(tempTarget).addClass('bg-false');
                }
                getCommentById(answerId);
                if ($myScope.answers[position].show == 0) {
                    $($event.target).removeClass('bg-false');
                    $($event.target).addClass('bg-true');
                    for (var i = 0; i < $myScope.answers.length; i++) {
                        if (i != position)
                            $myScope.answers[i].show = false;
                    }
                    $myScope.answers[position].show = true;
                } else {
                    $($event.target).removeClass('bg-true');
                    $($event.target).addClass('bg-false');
                    $myScope.answers[position].show = false;
                }
                tempTarget = $event.target;
                $("html,body").animate({scrollTop: $($event).offset().top}, 'slow');//1000是ms,也可以用slow代替
            };
            $myScope.addComment = function ($event, outerIndex, answerId) {
                addComment($event, outerIndex, answerId);
            };
            $("#loadmoreAnswers").html("加载更多评论");
        } else {
            if (JSON.stringify(response.data.data).length == 2) {
                layer.msg("已加载全部数据啦");
                $("#loadmoreAnswers").html("已加载全部评论");
            } else {
                $myScope.answers = $myScope.answers.concat(response.data.data);
            }
        }
    }, function errorCallback(response) {
        layer.msg('呀，出错了', {icon: 5});
    });
}
function getCommentById(answerId) {
    $myHttp({
        method: 'POST',
        url: url + 'index/getCommentFt',
        params: {comment_id: answerId, uid: userId}
    }).then(function successCallback(response) {
        $myScope.comments = response.data.data;
        $myScope.reComment = function ($event) {
            if (!sessionStorage.user) {
                window.open("login.html", "_self");
                return;
            }
            if ($($event.target).text() == "立即回复") {
                $($event.target).text("取消回复");
            } else {
                $($event.target).text("立即回复");
            }
            $($event.target).parent().next().toggle();
            $myScope.submit_reComment = function ($event, commentId, answerId, outIndex) {
                if (!sessionStorage.user) {
                    window.open("login.html", "_self");
                    return;
                }
                if ($($event.target).parent().prev().val() == "") {
                    layer.msg("请输入回复内容");
                } else {
                    addReply(commentId, answerId, $($event.target).parent().prev().val(), outIndex);
                }
            }
        }
    }, function errorCallback(response) {
        layer.msg('呀，出错了', {icon: 5});
    });
}
function addComment($event, outerIndex, answerId) {
    if (!sessionStorage.user) {
        window.open("login.html", "_self");
        return;
    } else {
        if ($($event.target).prev().prev().val() == "") {
            layer.msg("请输入评论内容");
            return;
        } else {
            $myHttp({
                method: 'POST',
                url: url + 'index/addComment',
                params: {
                    comment_id: answerId,
                    uid: userId,
                    article_id: articleId,
                    content: $($event.target).prev().prev().val(),
                    sec_comment_id: answerId,
                    token: token
                }
            }).then(function successCallback(response) {
                if(response.data.succeed==0){
                layer.msg("评论成功");
                getCommentById(answerId)
                $($event.target).prev().prev().val("");
                $myScope.answers[outerIndex].answer_num = $myScope.answers[outerIndex].answer_num + 1;
                }else{
                    layer.msg(response.data.msg);
                }
            }, function errorCallback(response) {
                layer.msg('呀，出错了', {icon: 5});
            });
        }
    }
}
function pubAnswer() {
    if (!sessionStorage.user) {
        window.open("login.html", "_self");
        return;
    } else {
        if ($("#text_answer").val() == "") {
            layer.msg("请输入回答内容");
        } else {
            $myHttp({
                method: 'POST',
                url: url + 'index/addComment',
                params: {uid: userId, token: token, article_id: articleId, content: $("#text_answer").val()}
            }).then(function successCallback(response) {
                if(response.data.succeed==0){
                answerPage = 1;
                getArticleComment();
                $("#text_answer").val("");
                layer.msg("评论成功");
                }else{
                    layer.msg(response.data.msg);
                }
            }, function errorCallback(response) {
                layer.msg('呀，出错了', {icon: 5});
            })
        }
    }
}
function addReply(commentId, answerId, content, outerIndex) {
    $myHttp({
        method: 'POST',
        url: url + 'index/addComment',
        params: {
            comment_id: commentId,
            uid: userId,
            article_id: articleId,
            content: content,
            sec_comment_id: answerId,
            token: token
        }
    }).then(function successCallback(response) {
        if(response.data.succeed==0){
        layer.msg("回复成功");
        $myScope.answers[outerIndex].answer_num = $myScope.answers[outerIndex].answer_num + 1;
        getCommentById(answerId)
        }else{
            layer.msg(response.data.msg);
        }
    }, function errorCallback(response) {
        layer.msg('呀，出错了', {icon: 5});
    });
}
function GetQueryString(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
    var r = window.location.search.substr(1).match(reg);
    if (r != null)return unescape(r[2]);
    return null;
}
var nav = $(".one"); //得到导航对象
var win = $(window); //得到窗口对象
var sc = $(document);//得到document文档对象。
win.scroll(function () {
    if (sc.scrollTop() >= 10) {
        nav.addClass("fix");
    } else {

        nav.removeClass("fix");
    }

});